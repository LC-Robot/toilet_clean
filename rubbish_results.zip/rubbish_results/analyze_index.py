import sys
import pandas as pd
import numpy as np

def analyze_index_file(file_path):
    """
    分析index.txt文件，计算成功率、平均置信度和调整后的平均推理时间
    
    Args:
        file_path (str): index.txt文件的路径
    """
    try:
        # 读取文件 - 使用更robust的方法
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        # 解析数据
        data = []
        for line in lines:
            line = line.strip()
            if line and not line.startswith('Test_ID'):  # 跳过标题行和空行
                # 使用正则表达式或更智能的分割方法
                parts = line.split('\t')
                # 清理空字符串
                parts = [p.strip() for p in parts if p.strip()]
                
                if len(parts) >= 4:
                    test_id = parts[0]
                    status = parts[1]
                    confidence = parts[2] if parts[2] != 'N/A' else None
                    inference_time = parts[3]
                    
                    data.append({
                        'Test_ID': test_id,
                        'Status': status,
                        'Avg_Confidence': confidence,
                        'Inference_Time(s)': inference_time
                    })
        
        df = pd.DataFrame(data)
        
        print(f"分析文件: {file_path}")
        print("=" * 50)
        
        # 调试信息 - 显示读取的数据
        print("读取的数据:")
        print(df)
        print()
        
        # 1. 计算成功率
        total_tests = len(df)
        success_count = len(df[df['Status'] == 'success'])
        success_rate = (success_count / total_tests) * 100
        
        print(f"总测试数: {total_tests}")
        print(f"成功数: {success_count}")
        print(f"失败数: {total_tests - success_count}")
        print(f"成功率: {success_rate:.2f}%")
        print()
        
        # 2. 计算平均置信度（只考虑成功的测试）
        success_df = df[df['Status'] == 'success']
        if len(success_df) > 0:
            # 将置信度列转换为数值，处理可能的N/A值
            confidence_values = pd.to_numeric(success_df['Avg_Confidence'], errors='coerce')
            avg_confidence = confidence_values.mean()
            print(f"平均置信度: {avg_confidence:.4f}")
        else:
            print("平均置信度: N/A (无成功测试)")
        print()
        
        # 3. 计算调整后的平均推理时间（去掉最大值和最小值）
        # 将推理时间列转换为数值
        inference_times = pd.to_numeric(df['Inference_Time(s)'], errors='coerce')
        
        if len(inference_times) > 2:
            # 排序
            sorted_times = sorted(inference_times.dropna())
            
            # 去掉最大值和最小值
            trimmed_times = sorted_times[1:-1]
            
            avg_inference_time = np.mean(trimmed_times)
            print(f"平均推理时间: {avg_inference_time:.4f}秒")
        else:
            avg_inference_time = np.mean(inference_times)
            print(f"推理时间数量不足3个，使用原始平均值")
            print(f"平均推理时间: {avg_inference_time:.4f}秒")
        
        print("=" * 50)
        
    except FileNotFoundError:
        print(f"错误: 找不到文件 {file_path}")
    except Exception as e:
        print(f"错误: {str(e)}")

def main():
    """
    主函数，处理命令行参数
    """
    if len(sys.argv) != 2:
        print("使用方法: python analyze_index.py <index.txt文件路径>")
        print("示例: python analyze_index.py rubbish_results/细小纸巾隔间内垂直0_7m/index.txt")
        sys.exit(1)
    
    file_path = sys.argv[1]
    analyze_index_file(file_path)

if __name__ == "__main__":
    main()